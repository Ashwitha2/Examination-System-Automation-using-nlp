<html> 
<head> 
    < tle> Welcome to NNRG e-Book's website</ tle> 
    <script language="javascript"> 
    func on validate() { 
        // username valida on 
        var uname = f1.username.value; 
        if (uname.length<=0) 
        { 
            alert("Please Enter UserName"); 
            f1.username.focus(); 
            return false; 
        } 
        if (uname.length < 8) 
        { 
            alert("Please enter UserName not less than 8"); 
            f1.username.focus(); 
            return false; 
        } 
        //password valida on 
        var pwd = f1.password.value; 
        if (pwd.length<=0) 
        { 
            alert("Please Enter password"); 
            f1.password.focus(); 
            return false; 
        } 
        if (pwd.length < 6) 
        { 
            alert("Please enter Password not less than 6"); 
            f1.password.focus(); 
            return false; 
        } 
        